const path = require("path");
const express = require("express");
require("dotenv").config();

global.__basedir = __dirname;

const app = express();
const http = require("http");
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
const db = require("./models");
const Camera = db.camera;
db.sequelize.authenticate()
  .then(() => {
    console.log('✅ Đã kết nối tới MySQL thành công!');
  })
  .catch(err => {
    console.error('❌ Lỗi kết nối tới MySQL:', err);
  });
const rtsp = require("rtsp-ffmpeg");

const authRoute = require("./route/auth");
const accountRoute = require("./route/account");
const activityRoute = require("./route/activity");
const classroomRoute = require("./route/classroom");
const cameraRoute = require("./route/camera");
const videoRoute = require("./route/video");
const resultRoute = require("./route/activity-sequence");
const statisticsRoute = require("./route/statistics");

var cors = require("cors");
const verifyToken = require("./middleware/verifyToken");

app.use(cors());
app.use(express.urlencoded({ limit: "200mb", extended: true }));
app.use(express.json({ limit: "200mb" }));

// react build
app.use(express.static(path.resolve(__dirname, "../client/build")));
//test api
app.get("/api/info", (req, res) => {
  res.json({ message: "Hello from server!" });
});
//routing
app.use("/api/auth", authRoute);
app.use("/api/account", verifyToken, accountRoute);
app.use("/api/activity", verifyToken, activityRoute);
app.use("/api/classroom", verifyToken, classroomRoute);
app.use("/api/camera", verifyToken, cameraRoute);
app.use("/api/video", verifyToken, videoRoute);
app.use("/api/result", verifyToken, resultRoute);
app.use("/api/statistics", verifyToken, statisticsRoute);

app.get("/api/stream/:cameraId", verifyToken, async (req, res) => {
  try {
    const camera = await Camera.findOne({
      where: { id: req.params.cameraId },
    });

    const stream = new rtsp.FFMpeg({
      input: camera.streamLink,
    });
    stream.on("start", function () {
      console.log("camera " + camera.id + " started");
    });
    stream.on("stop", function () {
      console.log("camera " + camera.id + " stopped");
    });
    const ns = io.of("/cam" + camera.id);
    ns.on("connection", function (wsocket) {
      console.log("connected to /cam" + camera.id);
      const pipeStream = function (data) {
        wsocket.emit("data", data.toString("base64"));
      };
      stream.on("data", pipeStream);

      wsocket.on("disconnect", function () {
        console.log("disconnected from /cam" + camera.id);
        stream.removeListener("data", pipeStream);
      });
    });

    res.json({
      success: true,
      message: "Socket On",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// async function stream() {
//   const cameras = await Camera.findAll();
//   const cams = cameras.map((item) => {
//     const stream = new rtsp.FFMpeg({
//       input: item.streamLink,
//     });
//     stream.on("start", function () {
//       console.log("camera " + item.id + " started");
//     });
//     stream.on("stop", function () {
//       console.log("camera " + item.id + " stopped");
//     });
//     return { id: item.id, stream };
//   });
//   cams.forEach(function (object, i) {
//     const ns = io.of("/cam" + object.id);
//     ns.on("connection", function (wsocket) {
//       console.log("connected to /cam" + i);
//       const pipeStream = function (data) {
//         wsocket.emit("data", data);
//       };
//       object.stream.on("data", pipeStream);

//       wsocket.on("disconnect", function () {
//         console.log("disconnected from /cam" + i);
//         object.stream.removeListener("data", pipeStream);
//       });
//     });
//   });
// }
// stream();

io.on("connection", function (socket) {
  socket.emit("start", "connected");
});
//

// app.get("/", (req, res) => {
//   res.sendFile(__dirname + "/index.html");
// });

// const db = require("./models");
// db.sequelize.sync();

// routing to react app
app.get("*", (req, res) => {
  res.sendFile(path.resolve(__dirname, "../client/build", "index.html"));
});

server.listen(process.env.PORT, () =>
  console.log(`Server start on port ${process.env.PORT}`)
);
server.timeout = 5 * 60 * 1000;

// app.listen(process.env.PORT, () =>
//   console.log(`Server start on port ${process.env.PORT}`)
// );
