module.exports = (db) => {
    db.classroom.hasMany(db.camera, { foreignKey: "classroom_id", as: "cameras" });
    db.camera.belongsTo(db.classroom, { foreignKey: "classroom_id", as: "room" });
  
    db.camera.hasMany(db.video, { foreignKey: "camera_id" });
    db.video.belongsTo(db.camera, { foreignKey: "camera_id" });
  
    // db.video.belongsToMany(db.activity, { through: db.videoActivities });
    // db.activity.belongsToMany(db.video, { through: db.videoActivities });
  
    db.video.hasMany(db.activitySequence, { foreignKey: "video_id" });
    db.activitySequence.belongsTo(db.video, { foreignKey: "video_id" });
  
    db.activity.hasMany(db.activitySequence, { foreignKey: "activity_id" });
    db.activitySequence.belongsTo(db.activity, { foreignKey: "activity_id" });
  
    db.activitySequence.hasMany(db.boundingBox, { foreignKey: "sequence_id" });
    db.boundingBox.belongsTo(db.activitySequence, { foreignKey: "sequence_id" });
  };
  