const express = require("express");
const router = new express.Router();
const db = require("../models");
const ffmpeg = require("fluent-ffmpeg");
const fs = require("fs");
const path = require("path");

const Video = db.video;
const Camera = db.camera;

//@route POST /api/statistics
//@desp Generate statistics for a specific camera and time range
//@private access
router.post("/", async (req, res) => {
  const { classroomId, cameraId, start_time, end_time } = req.body;

  if (!classroomId || !cameraId || !start_time || !end_time) {
    return res.status(400).json({ success: false, message: "Missing required fields!" });
  }

  try {
    // 1. Lấy thông tin camera
    const camera = await Camera.findOne({
      where: { id: cameraId, classroom_id: classroomId },
    });

    if (!camera) {
      return res.status(404).json({ success: false, message: "Camera not found" });
    }

    // 2. Cắt đoạn video từ camera
    const videoFileName = `video_${cameraId}_${Date.now()}.mp4`;
    const videoFilePath = path.join(__basedir, "resources", videoFileName);

    await new Promise((resolve, reject) => {
      ffmpeg(camera.streamLink)
        .setStartTime(start_time)
        .setDuration((new Date(end_time) - new Date(start_time)) / 1000) // Tính thời gian cắt
        .output(videoFilePath)
        .on("end", resolve)
        .on("error", reject)
        .run();
    });

    // 3. Chạy mô hình nhận diện hoạt động
    const resultFileName = `result_${cameraId}_${Date.now()}.txt`;
    const resultFilePath = path.join(__basedir, "resources", resultFileName);

    // Giả sử bạn có một hàm `runActivityRecognitionModel` để chạy mô hình
    const runActivityRecognitionModel = async (videoPath, outputPath) => {
      // Mô phỏng chạy mô hình và ghi kết quả vào file .txt
      const sampleData = `1 1 100 200 50 60\n2 1 110 210 50 60`; // Dữ liệu mẫu
      fs.writeFileSync(outputPath, sampleData);
    };

    await runActivityRecognitionModel(videoFilePath, resultFilePath);

    // 4. Lưu đường dẫn file kết quả vào bảng video
    const video = await Video.create({
      camera_id: cameraId,
      videoURL: videoFilePath,
      resultURL: resultFilePath,
      start_time,
      end_time,
    });

    res.json({
      success: true,
      message: "Statistics generated successfully",
      data: {
        videoId: video.id,
        videoURL: videoFilePath,
        resultURL: resultFilePath,
      },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;